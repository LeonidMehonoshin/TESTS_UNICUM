import time, random, re, asyncio, pyglet, os
from datetime import datetime

main_dir = os.path.dirname(__file__)
print(main_dir)

fullscreen = False
if fullscreen: window = pyglet.window.Window(fullscreen = True)
else: window = pyglet.window.Window(800, 600)

default_window = pyglet.graphics.Batch()
default_window_sizes = pyglet.graphics.Batch()
keys = pyglet.window.key.KeyStateHandler()
window.push_handlers(keys)

# pyglet.font.add_file('C:/Users/Unicum_Student/Desktop/pizza/JetBrainsMono-Medium.ttf')
bg_sprite = pyglet.resource.image("bg.jpg")
bg = pyglet.sprite.Sprite(bg_sprite, batch=default_window)

scale_factor = min(
    window.width / 800,
    window.height / 600
)

pizza_types_label = pyglet.text.Label(
'Pizza types', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 10 * scale_factor,
    anchor_x = 'center', batch = default_window
)
pizza0_label = pyglet.text.Label(
'a) Многогрибочковая(маленькая - 2$, большая - 4$)', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 24 * scale_factor,
    anchor_x = 'center', batch = default_window
)
pizza1_label = pyglet.text.Label(
'b) Ядерная(маленькая - 1$, большая - 2$)', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 36 * scale_factor,
    anchor_x = 'center', batch = default_window
)
pizza2_label = pyglet.text.Label(
'c) Та самая, которая нужна мне(маленькая - 1$, большая - 2$)', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 48 * scale_factor,
    anchor_x = 'center', batch = default_window
)
pizza3_label = pyglet.text.Label(
'd) Кастом мэйкер', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 60 * scale_factor,
    anchor_x = 'center', batch = default_window
)
size0_label = pyglet.text.Label(
'a) size 0', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=window.width // 2, y=window.height - 10 * scale_factor,
    anchor_x = 'center', batch = default_window
)
size1_label = pyglet.text.Label(
'a) size 1', #font_name = 'JetBrains Mono Medium',
    font_size = 24 * scale_factor, color = (255, 255, 255, 255),
    x=0, y=48 * scale_factor,
    anchor_x = 'center', batch = default_window
)

pyglet.options['audio'] = ('openal', 'pulse', 'silent', 'directsound', 'coreaudio')

# music = pyglet.resource.media(music, streaming=False)
# player = pyglet.media.Player()
# player.queue(music)
# player.loop = True
# player.play()
handled_keys = set()
def hanlde_events(keys, key_code):
    if keys[key_code]:
        if key_code not in handled_keys:
            handled_keys.add(key_code)
            return True
    else: handled_keys.discard(key_code)
    return False


running = 'types'
@window.event
def on_draw():
    window.clear()
    default_window.draw()
    if hanlde_events(keys, pyglet.window.key.A): pizza_type = 0
    elif hanlde_events(keys, pyglet.window.key.B): pizza_type = 1
    elif hanlde_events(keys, pyglet.window.key.C): pizza_type = 2
    elif hanlde_events(keys, pyglet.window.key.D): pizza_type = 3

pyglet.app.run()